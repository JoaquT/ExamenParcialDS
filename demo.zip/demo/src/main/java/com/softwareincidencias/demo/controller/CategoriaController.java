package com.softwareincidencias.demo.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.softwareincidencias.demo.dto.CategoriaResponse;
import com.softwareincidencias.demo.service.CategoriaService;

import lombok.RequiredArgsConstructor;
import java.util.List;
import java.util.NoSuchElementException;

@RestController
@RequestMapping("/categorias")
@RequiredArgsConstructor
public class CategoriaController {
    
    private final CategoriaService categoriaService;
    
    @GetMapping
    public ResponseEntity<List<CategoriaResponse>> listar() {
        return ResponseEntity.ok(categoriaService.listar());
    }
    
    @GetMapping("/{id}")
    public ResponseEntity<CategoriaResponse> obtener(@PathVariable Long id) {
        try {
            CategoriaResponse response = categoriaService.obtener(id);
            return ResponseEntity.ok(response);
        } catch (NoSuchElementException e) {
            return ResponseEntity.notFound().build();
        }
    }
} 



