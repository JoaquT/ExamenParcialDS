package com.softwareincidencias.demo.facade;

import com.softwareincidencias.demo.dto.ReporteRequest;
import com.softwareincidencias.demo.dto.ReporteResponse;
import com.softwareincidencias.demo.model.Categoria;
import com.softwareincidencias.demo.model.Usuario;
import com.softwareincidencias.demo.repository.CategoriaRepository;
import com.softwareincidencias.demo.repository.UsuarioRepository;
import com.softwareincidencias.demo.service.ReporteService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
// PATRÓN DE DISEÑO FACADE (FACHADA) APLICADO
public class IncidenciaFacade {

    private final CategoriaRepository categoriaRepository;
    private final UsuarioRepository usuarioRepository;
    private final ReporteService reporteService;

    public ReporteResponse registrarNuevaIncidencia(ReporteRequest request) {
        Categoria categoria = categoriaRepository.findById(request.getCategoriaId())
            .orElseThrow(() -> new IllegalArgumentException("La categoría especificada no existe"));

        Usuario usuario = null;
        if (request.getUsuarioEmail() != null && !request.getUsuarioEmail().isBlank()) {
            usuario = usuarioRepository.findByEmail(request.getUsuarioEmail())
                .orElseThrow(() -> new IllegalArgumentException("El usuario especificado no existe"));
        }

        return reporteService.crearConEntidades(request, categoria, usuario);
    }
}