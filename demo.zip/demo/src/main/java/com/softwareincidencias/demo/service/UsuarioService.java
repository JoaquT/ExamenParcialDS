package com.softwareincidencias.demo.service;

import com.softwareincidencias.demo.dto.UsuarioRequest;
import com.softwareincidencias.demo.dto.UsuarioResponse;
import com.softwareincidencias.demo.model.Usuario;
import com.softwareincidencias.demo.repository.UsuarioRepository;
import org.springframework.stereotype.Service;
import lombok.RequiredArgsConstructor;

import java.util.List;
import java.util.NoSuchElementException;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class UsuarioService {
    
    private final UsuarioRepository usuarioRepository;
    
    public UsuarioResponse registrar(UsuarioRequest request) {
        // Validaciones básicas
        if (request.getEmail() == null || request.getEmail().isBlank()) {
            throw new IllegalArgumentException("Email es requerido");
        }
        if (request.getPassword() == null || request.getPassword().length() < 8) {
            throw new IllegalArgumentException("Password debe tener mínimo 8 caracteres");
        }
        if (request.getNombre() == null || request.getNombre().isBlank()) {
            throw new IllegalArgumentException("Nombre es requerido");
        }
        
        // Verificar si el email ya existe en PostgreSQL
        if (usuarioRepository.findByEmail(request.getEmail()).isPresent()) {  
            throw new IllegalArgumentException("Email ya existe");
        }
        
        // Validar que si es supervisor/admin, requiere teléfono
        if (("supervisor".equals(request.getTipo()) || "admin".equals(request.getTipo())) &&
            (request.getTelefono() == null || request.getTelefono().isBlank())) {
            throw new IllegalArgumentException("Teléfono es obligatorio para supervisores y admins");
        }
        
        // Crear y llenar la Entidad
        Usuario usuario = new Usuario();
        usuario.setEmail(request.getEmail());
        usuario.setPassword(request.getPassword());
        usuario.setNombre(request.getNombre());
        usuario.setTipo(request.getTipo() != null ? request.getTipo() : "ciudadano");
        usuario.setTelefono(request.getTelefono());
        
        // Guardar en Base de Datos
        usuario = usuarioRepository.save(usuario);
        
        return mapearAResponse(usuario);
    }

    public String login(String email, String password) {
        Usuario usuario = usuarioRepository.findByEmail(email)
            .orElseThrow(() -> new NoSuchElementException("Usuario no encontrado"));

        if (!usuario.getPassword().equals(password)) {
            throw new SecurityException("Contraseña incorrecta");
        }

        return "token-provisional-valido-" + email;
    }
    
    public UsuarioResponse obtener(Long id) {
        return usuarioRepository.findById(id)
            .map(this::mapearAResponse)
            .orElseThrow(() -> new NoSuchElementException("Usuario no encontrado"));
    }
    
    public List<UsuarioResponse> listar() {
        return usuarioRepository.findAll().stream()
            .map(this::mapearAResponse)
            .collect(Collectors.toList());
    }
    
    public UsuarioResponse obtenerPorEmail(String email) {
        return usuarioRepository.findByEmail(email)
            .map(this::mapearAResponse)
            .orElseThrow(() -> new NoSuchElementException("Usuario no encontrado"));
    }

    private UsuarioResponse mapearAResponse(Usuario u) {
        return new UsuarioResponse(
            u.getId(), 
            u.getEmail(), 
            u.getNombre(), 
            u.getTipo(), 
            u.getTelefono(), 
            u.getFechaRegistro()
        );
    }
}