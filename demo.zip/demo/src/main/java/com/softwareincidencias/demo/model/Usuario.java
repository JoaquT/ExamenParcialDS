package com.softwareincidencias.demo.model;


import jakarta.persistence.*;
import lombok.Data;
import java.time.LocalDateTime;

@Data
@Entity
@Table(name = "usuarios")
public class Usuario {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @Column(unique = true, nullable = false)
    private String email;
    
    @Column(nullable = false)
    private String password; 
    
    private String nombre;
    private String tipo;
    private String telefono;
    private LocalDateTime fechaRegistro = LocalDateTime.now();
}

