package com.softwareincidencias.demo.controller;

import com.softwareincidencias.demo.dto.ReporteRequest;
import com.softwareincidencias.demo.dto.UsuarioRequest;
import com.softwareincidencias.demo.dto.UsuarioResponse;
import com.softwareincidencias.demo.facade.IncidenciaFacade;
import com.softwareincidencias.demo.service.CategoriaService;
import com.softwareincidencias.demo.service.ReporteService;
import com.softwareincidencias.demo.service.UsuarioService;
import jakarta.servlet.http.HttpSession;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequiredArgsConstructor
public class FrontendController {

    private final ReporteService reporteService;
    private final CategoriaService categoriaService;
    private final UsuarioService usuarioService;
    private final IncidenciaFacade incidenciaFacade;

    // --- ACCESO Y SEGURIDAD ---

    @GetMapping("/login")
    public String vistaLogin() {
        return "login";
    }

    @PostMapping("/login")
    public String procesarLogin(@RequestParam String email, @RequestParam String password, HttpSession session, Model model) {
        try {
            usuarioService.login(email, password);
            session.setAttribute("usuarioLogueado", usuarioService.obtenerPorEmail(email));
            return "redirect:/";
        } catch (Exception e) {
            model.addAttribute("error", "Credenciales incorrectas. Intenta de nuevo.");
            return "login";
        }
    }

    @GetMapping("/registro")
    public String vistaRegistro(Model model) {
        model.addAttribute("usuario", new UsuarioRequest());
        return "register";
    }

    @PostMapping("/registro")
    public String procesarRegistro(@ModelAttribute UsuarioRequest request, Model model) {
        try {
            usuarioService.registrar(request);
            return "redirect:/login?registrado=true";
        } catch (Exception e) {
            model.addAttribute("error", e.getMessage());
            return "register";
        }
    }

    @GetMapping("/logout")
    public String logout(HttpSession session) {
        session.invalidate();
        return "redirect:/login";
    }

    // --- DASHBOARD (SOLO LOGUEADOS) ---

    @GetMapping("/")
    public String index(Model model, HttpSession session) {
        if (session.getAttribute("usuarioLogueado") == null) {
            return "redirect:/login";
        }
        
        model.addAttribute("reportes", reporteService.listar());
        model.addAttribute("categorias", categoriaService.listar());
        model.addAttribute("nuevoReporte", new ReporteRequest());
        return "index";
    }

    // --- ACCIONES DE GESTIÓN ---

    @PostMapping("/reportar")
    public String crearReporte(@ModelAttribute ReporteRequest request) {
        request.setLatitud(-12.0464); 
        request.setLongitud(-77.0428);
        incidenciaFacade.registrarNuevaIncidencia(request);
        return "redirect:/";
    }

    @PostMapping("/dashboard/estado")
    public String cambiarEstado(@RequestParam Long id, @RequestParam String estado, HttpSession session) {
        UsuarioResponse usuario = (UsuarioResponse) session.getAttribute("usuarioLogueado");
        
        // Si no es supervisor, lo bloqueamos y redirigimos con un mensaje de error
        if (usuario == null || !"supervisor".equals(usuario.getTipo())) {
            return "redirect:/?error=acceso_denegado";
        }
        
        reporteService.cambiarEstado(id, estado);
        return "redirect:/";
    }

    // NUEVA RUTA Y VALIDACIÓN DE ROL (SUPERVISOR)
    @PostMapping("/dashboard/eliminar")
    public String eliminarReporte(@RequestParam Long id, HttpSession session) {
        UsuarioResponse usuario = (UsuarioResponse) session.getAttribute("usuarioLogueado");
        
        if (usuario == null || !"supervisor".equals(usuario.getTipo())) {
            return "redirect:/?error=acceso_denegado";
        }
        
        reporteService.eliminar(id);
        return "redirect:/";
    }
}