package com.softwareincidencias.demo.service;

import com.softwareincidencias.demo.dto.ReporteRequest;
import com.softwareincidencias.demo.dto.ReporteResponse;
import com.softwareincidencias.demo.model.Categoria;
import com.softwareincidencias.demo.model.Reporte;
import com.softwareincidencias.demo.model.Usuario;
import com.softwareincidencias.demo.repository.ReporteRepository;
import org.springframework.stereotype.Service;
import lombok.RequiredArgsConstructor;

import java.util.List;
import java.util.NoSuchElementException;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class ReporteService {
    
    private final ReporteRepository reporteRepository;
    
    // Nuevo método usado por la Fachada aplicando el patrón Builder
    public ReporteResponse crearConEntidades(ReporteRequest request, Categoria categoria, Usuario usuario) {
        
        // Uso del Patrón Builder para crear el objeto de forma limpia
        Reporte reporte = Reporte.builder()
            .titulo(request.getTitulo())
            .descripcion(request.getDescripcion())
            .latitud(request.getLatitud())
            .longitud(request.getLongitud())
            .estado("nuevo")
            .prioridad("media")
            .categoria(categoria)
            .usuario(usuario)
            .build();
            
        reporte = reporteRepository.save(reporte);
        return mapearAResponse(reporte);
    }
    
    public ReporteResponse obtener(Long id) {
        return reporteRepository.findById(id)
            .map(this::mapearAResponse)
            .orElseThrow(() -> new NoSuchElementException("Reporte no encontrado"));
    }
    
    public List<ReporteResponse> listar() {
        return reporteRepository.findAll().stream()
            .map(this::mapearAResponse)
            .collect(Collectors.toList());
    }
    
    public List<ReporteResponse> listarPorEstado(String estado) {
        return reporteRepository.findByEstado(estado).stream()
            .map(this::mapearAResponse)
            .collect(Collectors.toList());
    }
    
    public ReporteResponse cambiarEstado(Long id, String nuevoEstado) {
        Reporte reporte = reporteRepository.findById(id)
            .orElseThrow(() -> new NoSuchElementException("Reporte no encontrado"));
        
        List<String> estadosValidos = List.of("nuevo", "revisado", "asignado", "en_proceso", "resuelto", "cerrado");
        
        if (!estadosValidos.contains(nuevoEstado)) {
            throw new IllegalArgumentException("Estado no válido: " + nuevoEstado);
        }
        
        reporte.setEstado(nuevoEstado);
        reporte = reporteRepository.save(reporte);
        return mapearAResponse(reporte);
    }
    
    public void eliminar(Long id) {
        if (!reporteRepository.existsById(id)) {
            throw new NoSuchElementException("Reporte no encontrado");
        }
        reporteRepository.deleteById(id);
    }

    private ReporteResponse mapearAResponse(Reporte r) {
        Long categoriaId = r.getCategoria() != null ? r.getCategoria().getId() : null;
        Long usuarioId = r.getUsuario() != null ? r.getUsuario().getId() : null;

        return new ReporteResponse(
            r.getId(), r.getTitulo(), r.getDescripcion(), r.getLatitud(), r.getLongitud(),
            categoriaId, r.getEstado(), r.getPrioridad(), r.getFechaCreacion(), usuarioId
        );
    }
}