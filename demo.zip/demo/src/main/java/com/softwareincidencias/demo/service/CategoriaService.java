package com.softwareincidencias.demo.service;

import com.softwareincidencias.demo.dto.CategoriaResponse;
import com.softwareincidencias.demo.model.Categoria;
import com.softwareincidencias.demo.repository.CategoriaRepository;
import org.springframework.stereotype.Service;
import lombok.RequiredArgsConstructor;

import java.util.List;
import java.util.NoSuchElementException;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class CategoriaService {
    
    private final CategoriaRepository categoriaRepository;
    
    public List<CategoriaResponse> listar() {
        return categoriaRepository.findAll().stream()
            .map(this::mapearAResponse)
            .collect(Collectors.toList());
    }
    
    public CategoriaResponse obtener(Long id) {
        return categoriaRepository.findById(id)
            .map(this::mapearAResponse)
            .orElseThrow(() -> new NoSuchElementException("Categoría no encontrada"));
    }

    // Función auxiliar para convertir Entidad -> DTO
    private CategoriaResponse mapearAResponse(Categoria c) {
        return new CategoriaResponse(
            c.getId(), 
            c.getNombre(), 
            c.getDescripcion(), 
            c.getIcono(), 
            c.getColor()
        );
    }
}